#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "esp8266.h"
#include "ls1c102_interrupt.h"
#include "iic.h"
#include "dht11.h"
#include "BEEP.h"
#include "key.h"
#include "led.h"
#include "ls1c102_ptimer.h"
#include "ls1x_common.h"
#include "ls1x_exti.h"
#include "ls1x_rtc.h"
#include "ls1c102_touch.h"
#include "ls1x_string.h"
#include "ls1x_wdg.h"
#include "ls1x_spi.h"
#include "ls1c102_i2c.h"
#include "ls1x_uart.h"
#include "ls1x_clock.h"
#include "ls1c102_adc.h"
#include "oled.h"
#include "flame.h"

#define LED 20
#define _ADCX_R 510	
#define beep GPIO_PIN_63
#define VOUT GPIO_PIN_17
#define R0 	58769
char str[50];
static uint16_t temperature;
static uint16_t humidity;
unsigned short value;
int time = 0;
uint8_t received_data = 0;
int16_t adcx_temp,vol,temp;
int32_t Rs;
uint8_t data[8] = {0x55, 0xAA, 0x00, 0x00, 0x00, 0x00, 0x00, 0xBB}; 

int main(int arg, char *args[])
{
    SystemClockInit(); 
    GPIOInit();        
    OLED_Init();
    EnableInt(); 
    Uart0_init(115200);                           
    AFIO_RemapConfig(AFIOB, GPIO_Pin_14, 0);       
    Adc_powerOn();                                 
    Adc_open(ADC_CHANNEL_I4);  
    BEEP_Init();
    Flame_Init(); 
    Uart0_init(9600); 
    OLED_Show_Str(10, 0, "温湿度火焰监测", 16); 

    while (DHT11_Init()) 
    {
        OLED_Show_Str(10, 4, "未检测到传感器", 16); 
    }
    OLED_Show_Str(0, 4, "                ", 16); 
    OLED_Show_Str(20, 3, "温度:     ℃", 16);     
    OLED_Show_Str(20, 6, "湿度:     %RH", 16);
    delay_ms(1000);
    while (1)
    {
        DHT11_Read_Data(&temperature, &humidity); 
        data[2] = temperature / 10;     
        data[3] = humidity / 10;
        sprintf(str, "%2d", temperature / 10);     
        OLED_Show_Str(70, 3, str, 16);           
        sprintf(str, "%2d", humidity / 10);
        OLED_Show_Str(70, 6, str, 16);           
    
        if(wifi_connected == 0)
        {
            if(esp8266_check_cmd('T'))     
            {
                OLED_Clear(); 
                wifi_connected = 1;
                OLED_Show_Str(12, 3, "已连接到WIFI", 16);
                delay_ms(1000);
                OLED_Clear(); 
                delay_ms(500);
                OLED_Show_Str(5, 0, "烟雾浓度：", 16); 
                OLED_Show_Str(20, 3, "温度:    ℃", 16);     
                OLED_Show_Str(20, 6, "湿度:    %RH", 16);
                gpio_write_pin(LED, 1);
                BEEP_ON;
                delay_ms(500);
                BEEP_OFF;
            }
        }
        if(wifi_connected == 1)
        {
            delay_ms(1500);
            data[6] = (data[2] + data[3] + data[4] + data[5]) % 256;  
            printf("%s",data);
            UART_SendDataALL(UART0, data, 8);
        }
        if(temperature / 10>45 & humidity / 10<25)
	    {
		    gpio_write_pin(GPIO_PIN_63, 1); ;
            delay_ms(2000);
            gpio_write_pin(GPIO_PIN_63, 0); ;
            delay_ms(2000);
	    }
         
        Flame();

        adcx_temp=Adc_Measure(ADC_CHANNEL_I4);
        vol = adcx_temp *33/ 40960;					
	    Rs = 50000/vol-20000;							
	    temp = Rs / R0;
        temp=1/(temp*temp);
        temp =	(61045/100)* temp;
	    if(temp>9999)
	    {
		    temp = 9999;
	    }
    
        if(temp>40)
        {
            gpio_write_pin(GPIO_PIN_63, 1); ;
            delay_ms(2000);
            gpio_write_pin(GPIO_PIN_63, 0); ;
            delay_ms(2000);
        }
         data[4] = temp;
         printf("烟雾浓度：%4d", value);  
         sprintf(str,"%4d ", temp );
         UART_SendDataALL(UART0, str, strlen(str)); 
	    OLED_Show_Str(75, 0, str, 16);
        delay_ms(1000);
    }

    return 0;
}
