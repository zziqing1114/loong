#include "flame.h"
#include "beep.h"
#include "ls1x_gpio.h"


void Flame_Init(void)
{
					
    gpio_set_direction(GPIO_PIN_36, GPIO_Mode_In);
}

void FLAME_IO_In(void)
{
	gpio_set_direction(GPIO_PIN_36, GPIO_Mode_In);
}

void FALME_IO_Out(void)
{
	gpio_set_direction(GPIO_PIN_36, GPIO_Mode_Out);
}

void Flame(void)
{
	if(flame() == 0)
	{
		
		 OLED_Clear(); 
		 OLED_Show_Str(12, 0, "WARN", 16);
        BEEP_ON;
        delay_ms(2000);
        BEEP_OFF;
        delay_ms(2000);
	}
	else if(flame() == 1)
	{
		OLED_Show_Str(5, 0, "烟雾浓度：", 16); 
        OLED_Show_Str(20, 3, "温度:    ℃", 16);     
        OLED_Show_Str(20, 6, "湿度:    %RH", 16);
	}
}

