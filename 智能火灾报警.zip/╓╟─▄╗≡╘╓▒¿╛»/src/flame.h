#ifndef __FLAME_H
#define __FLAME_H

#define flame()	 gpio_get_pin(GPIO_PIN_36)

void Flame_Init(void);
void Flame(void);

#endif

