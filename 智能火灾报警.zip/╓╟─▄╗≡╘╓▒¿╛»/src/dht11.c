#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "dht11.h"


void DHT11_Rst(void)
{
	DHT11_IO_Out();	 
	DHT11_DQ_OUT(0); 
	delay_ms(20);	 
	DHT11_DQ_OUT(1); 
	delay_us(30);	 
}

void DHT11_IO_In(void)
{
	gpio_set_direction(GPIO_PIN_35, GPIO_Mode_In);
}

void DHT11_IO_Out(void)
{
	gpio_set_direction(GPIO_PIN_35, GPIO_Mode_Out);
}

uint8_t DHT11_Check(void)
{
	uint8_t retry = 0;
	DHT11_IO_In();					   
	while (DHT11_DQ_IN && retry < 100) 
	{
		retry++;
	}
	if (retry >= 100)
		return 1;
	else
		retry = 0;
	while (!DHT11_DQ_IN && retry < 100) 
	{
		retry++;
	};
	if (retry >= 100)
		return 1;
	return 0;
}

uint8_t DHT11_Read_Bit(void)
{
	uint8_t retry = 0;
	while (DHT11_DQ_IN && retry < 100) 
	{
		retry++;
	}
	retry = 0;
	while (!DHT11_DQ_IN && retry < 100) 
	{
		retry++;
	}
	delay_us(40); 
	if (DHT11_DQ_IN)
		return 1;
	else
		return 0;
}

uint8_t DHT11_Read_Byte(void)
{
	uint8_t i, dat;
	dat = 0;
	for (i = 0; i < 8; i++)
	{
		dat <<= 1;
		dat |= DHT11_Read_Bit();
	}
	return dat;
}

uint8_t DHT11_Read_Data(uint16_t *temp,uint16_t *humi)    
{        
 	uint8_t buf[5];
	uint8_t i;
	DHT11_Rst();
	if(DHT11_Check()==0)
	{
		for(i=0;i<5;i++)	
		{
			buf[i]=DHT11_Read_Byte();
		}
		if((buf[0]+buf[1]+buf[2]+buf[3])==buf[4])
		{
			*humi = buf[0] * 10 + buf[1];
			*temp = buf[2] * 10 + buf[3];
		}
	}
	else return 1;
	return 0;	    
}

uint8_t DHT11_Init(void)
{
	gpio_pin_remap(GPIO_PIN_35, GPIO_FUNC_GPIO);
	DHT11_IO_Out();
	DHT11_Rst();
	return DHT11_Check();
}

