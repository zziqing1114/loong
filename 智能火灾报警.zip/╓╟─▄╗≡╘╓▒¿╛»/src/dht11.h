#ifndef __DHT11_H
#define __DHT11_H 

#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1c102_ptimer.h"
#include "ls1x_common.h"
#include "ls1x_gpio.h"
#include "ls1x_exti.h"
#include "ls1x_latimer.h"
#include "ls1x_rtc.h"
#include "ls1c102_touch.h"
#include "ls1x_string.h"
#include "ls1x_wdg.h"
#include "ls1x_uart.h"
#include "ls1x_spi.h"
#include "ls1c102_i2c.h"
#include "Config.h"

	   
#define	DHT11_DQ_OUT(X)   	gpio_write_pin(GPIO_PIN_35,X)
#define	DHT11_DQ_IN    		gpio_get_pin(GPIO_PIN_35)

uint8_t DHT11_Init(void);
uint8_t DHT11_Read_Data(uint16_t *temp,uint16_t *humi);
uint8_t DHT11_Read_Byte(void);
uint8_t DHT11_Read_Bit(void);
uint8_t DHT11_Check(void);
void DHT11_Rst(void);    

void DHT11_IO_Out(void);
void DHT11_IO_In(void);


#endif















